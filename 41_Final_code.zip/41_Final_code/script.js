// const maxDataPoints = 20;
//         let heartRateData = [];
//         let spo2Data = [];
//         let motionData = [];
//         let timestamps = [];

//         // Initialize the charts
//         const heartRateChart = new Chart(document.getElementById('heartRateChart').getContext('2d'), {
//             type: 'line',
//             data: {
//                 labels: timestamps,
//                 datasets: [{
//                     label: 'Heart Rate (bpm)',
//                     data: heartRateData,
//                     borderColor: 'red',
//                     fill: false,
//                 }]
//             },
//             options: {
//                 responsive: true,
//                 scales: {
//                     x: { title: { display: true, text: 'Time' } },
//                     y: { title: { display: true, text: 'Heart Rate (bpm)' } }
//                 }
//             }
//         });

//         const spo2Chart = new Chart(document.getElementById('spo2Chart').getContext('2d'), {
//             type: 'line',
//             data: {
//                 labels: timestamps,
//                 datasets: [{
//                     label: 'SpO₂ (%)',
//                     data: spo2Data,
//                     borderColor: 'blue',
//                     fill: false,
//                 }]
//             },
//             options: {
//                 responsive: true,
//                 scales: {
//                     x: { title: { display: true, text: 'Time' } },
//                     y: { title: { display: true, text: 'SpO₂ (%)' } }
//                 }
//             }
//         });

//         const motionChart = new Chart(document.getElementById('motionChart').getContext('2d'), {
//             type: 'line',
//             data: {
//                 labels: timestamps,
//                 datasets: [{
//                     label: 'Motion Detected (1/0)',
//                     data: motionData,
//                     borderColor: 'green',
//                     fill: false,
//                 }]
//             },
//             options: {
//                 responsive: true,
//                 scales: {
//                     x: { title: { display: true, text: 'Time' } },
//                     y: { title: { display: true, text: 'Motion (Yes/No)' } }
//                 }
//             }
//         });

//     async function fetchData() {
//         try {
//             console.log("Fetching data at", new Date().toLocaleTimeString());
//             const response = await fetch("../data.json?nocache=" + new Date().getTime());
//             const data = await response.json();

//             // Get the last 20 entries
//             const latestEntries = data.slice(-maxDataPoints);

//             // Update arrays
//             heartRateData.length = 0;
//             spo2Data.length = 0;
//             motionData.length = 0;
//             timestamps.length = 0;

//             latestEntries.forEach((entry, index) => {
//                                     heartRateData.push(entry.HeartRate);
//                                     spo2Data.push(entry.SpO2);
//                                     motionData.push(entry.Motion === "1" ? 1 : 0);
//                                     timestamps.push(index + 1);  // Push numbers from 1 to 20 (index + 1)
//                                 });

//             // Update the charts
//             heartRateChart.update();
//             spo2Chart.update();
//             motionChart.update();
//         } catch (error) {
//             console.error("Error fetching or updating data:", error);
//         }
//     }

//     setInterval(fetchData(), 10000); // Ensure single timer setup
//     console.log("hi");
// const maxDataPoints = 20;
// let heartRateData = [];
// let spo2Data = [];
// let motionData = [];
// let timestamps = [];
// let lastFetchTime = 0;  // Store the timestamp of the last fetch

// // Initialize the charts
// const heartRateChart = new Chart(document.getElementById('heartRateChart').getContext('2d'), {
//     type: 'line',
//     data: {
//         labels: timestamps,
//         datasets: [{
//             label: 'Heart Rate (bpm)',
//             data: heartRateData,
//             borderColor: 'red',
//             fill: false,
//         }]
//     },
//     options: {
//         responsive: true,
//         scales: {
//             x: { title: { display: true, text: 'Time' } },
//             y: { title: { display: true, text: 'Heart Rate (bpm)' } }
//         }
//     }
// });

// const spo2Chart = new Chart(document.getElementById('spo2Chart').getContext('2d'), {
//     type: 'line',
//     data: {
//         labels: timestamps,
//         datasets: [{
//             label: 'SpO₂ (%)',
//             data: spo2Data,
//             borderColor: 'blue',
//             fill: false,
//         }]
//     },
//     options: {
//         responsive: true,
//         scales: {
//             x: { title: { display: true, text: 'Time' } },
//             y: { title: { display: true, text: 'SpO₂ (%)' } }
//         }
//     }
// });

// const motionChart = new Chart(document.getElementById('motionChart').getContext('2d'), {
//     type: 'line',
//     data: {
//         labels: timestamps,
//         datasets: [{
//             label: 'Motion Detected (1/0)',
//             data: motionData,
//             borderColor: 'green',
//             fill: false,
//         }]
//     },
//     options: {
//         responsive: true,
//         scales: {
//             x: { title: { display: true, text: 'Time' } },
//             y: { title: { display: true, text: 'Motion (Yes/No)' } }
//         }
//     }
// });

// function fetchData() {
//     const currentTime = Date.now();
    
//     // Only fetch data if 10 seconds have passed since the last fetch
//     if (currentTime - lastFetchTime >= 10000) {
//         console.log("Fetching data at", new Date().toLocaleTimeString());
//         fetch("../data.json")
//             .then(response => response.json())
//             .then(data => {
//                 // Get the last 20 entries
//                 const latestEntries = data.slice(-maxDataPoints);

//                 // Clear existing data in arrays
//                 heartRateData.length = 0;
//                 spo2Data.length = 0;
//                 motionData.length = 0;
//                 timestamps.length = 0;

//                 // Update the arrays with the latest data
//                 latestEntries.forEach((entry, index) => {
//                     heartRateData.push(entry.HeartRate);
//                     spo2Data.push(entry.SpO2);
//                     motionData.push(entry.Motion === "1" ? 1 : 0);
//                     timestamps.push(index + 1);  // Push numbers from 1 to 20 (index + 1)
//                 });
                

//                 // Update the charts
//                 heartRateChart.update();
//                 spo2Chart.update();
//                 motionChart.update();

//                 // Update the last values shown on the page
//                 const lastEntry = latestEntries[latestEntries.length - 1];
//                 document.getElementById("lastHeartRate").innerText = `Last Heart Rate: ${lastEntry.HeartRate} bpm`;
//                 document.getElementById("lastSpO2").innerText = `Last SpO₂: ${lastEntry.SpO2} %`;
//                 document.getElementById("lastMotion").innerText = `Last Motion: ${lastEntry.Motion === "1" ? "Detected" : "Not Detected"}`;

//                 // Update the last fetch time
//                 lastFetchTime = currentTime;
//             })
//             .catch(error => {
//                 console.error("Error fetching or updating data:", error);
//             });
//     }
// }

// // Set up the interval to check for data every second, but only fetch if 10 seconds have passed
// setInterval(fetchData, 1000);

// // Initial call to load data
// fetchData();
const maxDataPoints = 20;
let heartRateData = [];
let spo2Data = [];
let motionData = [];
let timestamps = [];
let lastFetchTime = 0; // Timestamp of the last fetch
let sleepApneaDetected = false; // Tracks whether sleep apnea has been detected

// Initialize the charts
const heartRateChart = new Chart(document.getElementById('heartRateChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: timestamps,
        datasets: [{
            label: 'Heart Rate (bpm)',
            data: heartRateData,
            borderColor: 'red',
            fill: false,
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: { title: { display: true, text: 'Time' } },
            y: { title: { display: true, text: 'Heart Rate (bpm)' } }
        }
    }
});

const spo2Chart = new Chart(document.getElementById('spo2Chart').getContext('2d'), {
    type: 'line',
    data: {
        labels: timestamps,
        datasets: [{
            label: 'SpO₂ (%)',
            data: spo2Data,
            borderColor: 'blue',
            fill: false,
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: { title: { display: true, text: 'Time' } },
            y: { title: { display: true, text: 'SpO₂ (%)' } }
        }
    }
});

const motionChart = new Chart(document.getElementById('motionChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: timestamps,
        datasets: [{
            label: 'Motion Detected (1/0)',
            data: motionData,
            borderColor: 'green',
            fill: false,
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: { title: { display: true, text: 'Time' } },
            y: { title: { display: true, text: 'Motion (Yes/No)' } }
        }
    }
});

function fetchData() {
    const currentTime = Date.now();

    // Only fetch data if 10 seconds have passed since the last fetch
    console.log("Fetching data at", new Date().toLocaleTimeString());
    fetch("../new_data.json")
        .then(response => response.json())
        .then(data => {
            // Get the last 20 entries
            const latestEntries = data.slice(-maxDataPoints);

            // Clear existing data in arrays
            heartRateData.length = 0;
            spo2Data.length = 0;
            motionData.length = 0;
            timestamps.length = 0;

            // Track previous values to detect sleep apnea
            let prevHeartRate = null;
            let prevSpO2 = null;
            let prevMotion = null;

            // Update the arrays with the latest data
            latestEntries.forEach((entry, index) => {
                const currentHeartRate = parseInt(entry.HeartRate, 10);
                const currentSpO2 = parseInt(entry.SpO2, 10);
                const currentMotion = entry.Motion === "1" ? 1 : 0;

                heartRateData.push(currentHeartRate);
                spo2Data.push(currentSpO2);
                motionData.push(currentMotion);
                timestamps.push(index + 1); // Numbers 1 to 20

                // Detect sleep apnea
                if (prevHeartRate !== null && prevSpO2 !== null && prevMotion !== null) {
                    if (
                        Math.abs(currentHeartRate - prevHeartRate) > 5 &&
                        Math.abs(currentSpO2 - prevSpO2) > 3 &&
                        Math.abs(currentMotion - prevMotion) >= 1
                    ) {
                        sleepApneaDetected = true; // Once detected, it remains true
                    }
                }

                // Update previous values
                prevHeartRate = currentHeartRate;
                prevSpO2 = currentSpO2;
                prevMotion = currentMotion;
            });

            // Update the charts
            heartRateChart.update();
            spo2Chart.update();
            motionChart.update();

            // Update the last values shown on the page
            const lastEntry = latestEntries[latestEntries.length - 1];
            document.getElementById("lastHeartRate").innerText = `Last Heart Rate: ${lastEntry.HeartRate} bpm`;
            document.getElementById("lastSpO2").innerText = `Last SpO₂: ${lastEntry.SpO2} %`;
            document.getElementById("lastMotion").innerText = `Last Motion: ${lastEntry.Motion === "1" ? "Detected" : "Not Detected"}`;
            document.getElementById("sleepApneaStatus").innerText = `Sleep Apnea Detected: ${sleepApneaDetected ? "Yes" : "No"}`;

            // Update the last fetch time
            lastFetchTime = currentTime;
        })
        .catch(error => {
            console.error("Error fetching or updating data:", error);
        });
}

// Set up the interval to check for data every second, but only fetch if 10 seconds have passed
setInterval(fetchData, 1000);

// Initial call to load data
fetchData();
