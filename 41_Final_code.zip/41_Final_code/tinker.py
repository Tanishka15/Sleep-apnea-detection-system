import serial
import time
import os
import json

# Configure the serial connection
arduino_port = "COM8"  # Replace with your Arduino's serial port
baud_rate = 9600       # Match the baud rate set in the Arduino code
file_path = "new_data.json"


try:
    ser = serial.Serial(arduino_port, baud_rate, timeout=1)
    print(f"Connected to Arduino on {arduino_port}")
    time.sleep(2)  # Wait for connection to establish

    while True:
        if ser.in_waiting > 0:  # Check if data is available
            data = ser.readline().decode('utf-8').strip()
            print(data)
            print(f"Received: {data}")
            print(f"new:{data[11:13]}\nnew:{data[25:27]}\nnew:{data[38]}")
            # New data to add or update
            new_entry = {
                "HeartRate": data[11:13],
                "SpO2": data[25:27],
                "Motion": data[38]
            }
            # Check if the file exists
            if os.path.exists(file_path):
                # Open and read the existing data
                with open(file_path, "r") as file:
                    try:
                        data = json.load(file)  # Load existing JSON data
                    except json.JSONDecodeError:
                        data = []  # If file is empty, start with an empty list
            else:
                data = []  # If file doesn't exist, create a new list
            # Append the new entry to the data
            data.append(new_entry)

            # Write the updated data back to the file
            with open(file_path, "w") as file:
                json.dump(data, file, indent=4)
except serial.SerialException as e:
    print(f"Error: {e}")
finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
        print("Serial connection closed.")

